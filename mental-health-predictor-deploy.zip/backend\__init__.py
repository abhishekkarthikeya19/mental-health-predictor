# backend/__init__.py
"""
Mental Health Predictor API package.
"""

__version__ = "1.0.0"